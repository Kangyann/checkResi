<?php
$awb = $_POST['inputResi'];
$courier = $_POST['codeCourier'];
$api = '56b861371bb8a99a644b2165a6584141bea0caa874dd39983a7592e8b0742180';
$track = 'https://api.binderbyte.com/v1/track?api_key=' . $api . '&courier=' . $courier . '&awb=' . $awb;
$resApi = file_get_contents($track);
$set = json_decode($resApi, true);
header("Content-Type: application/json");   
echo json_encode($set);

